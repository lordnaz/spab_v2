/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./resources/assets/js/scripts.js ***!
  \****************************************/
(function (window, undefined) {
  'use strict';
  /*
  NOTE:
  ------
  PLACE HERE YOUR OWN JAVASCRIPT CODE IF NEEDED
  WE WILL RELEASE FUTURE UPDATES SO IN ORDER TO NOT OVERWRITE YOUR JAVASCRIPT CODE PLEASE CONSIDER WRITING YOUR SCRIPT HERE.  */

  var ringgitClass = $('.ringgit'),
  baseURL = 'http://127.0.0.1:8000/', 
  usd_convert;
  var isRtl = $('html').attr('data-textdirection') === 'rtl';

  $('.copyClipboard').on('click', function (event) {

    let text = event.currentTarget.attributes["trx-id"].value;

    // alert(text)

    navigator.clipboard.writeText(event.currentTarget.attributes["trx-id"].value)
      .then(() => {
        copyToClipboardToast()
        // alert('Text copied to clipboard');
      })
      .catch(err => {
        errorCopyToClipboardToast(err)
        // alert('Error in copying text: ', err);
      });
    
  });

  ringgitClass.on('change', function (bp) {
    // alert('hello: ' + ringgitClass.val());
    $.ajax({
      type: 'GET',
      dataType: 'json',
      async: false,
      url: baseURL + 'api/get_rate',
      headers: { 
          'Authorization': `Bearer mu7Ig3EQ2OM5YuWkZSwXKrn19bt3l8EoqRVbvOZG`,
          'Content-Type': 'application/json'
      },
      success: function (response) {
        // console.log('data: ', response)

        if(response){

          // successAlert();

          usd_convert = ringgitClass.val() / response;

          document.getElementById('usdollar').value = usd_convert.toFixed(2);

        }else{
          document.getElementById('usdollar').value = "Rate not available";
        }

      }
    });

  }); 


  // On load Toast
  function copyToClipboardToast(){
    setTimeout(function () {
      toastr['success'](
        '',
        'Copied to clipboard',
        {
          closeButton: true,
          tapToDismiss: false,
          rtl: isRtl
        }
      );
    }, 200);
  }

  function errorCopyToClipboardToast(err){
    setTimeout(function () {
      toastr['success'](
        'ErrCode: ' + err,
        'Copy Error',
        {
          closeButton: true,
          tapToDismiss: false,
          rtl: isRtl
        }
      );
    }, 200);
  }

  // $.ajax({
  //   type: 'GET',
  //   dataType: 'json',
  //   async: false,
  //   url: baseURL + 'api/api_trx_list',
  //   headers: { 
  //       'Authorization': `Bearer tIK1f3AJeGuPkz2FJpDf1OUlt2tjc2mlN5lWf4oZ`,
  //       'Content-Type': 'application/json'
  //   },
  //   success: function (data) {
  //     console.log('data: ', data)
  //   }
  // });

  
})(window);
/******/ })()
;