# Terms of Service

Updated at 2022-01-06

By accessing and placing an order with eastcoast.asia, you confirm that you are in agreement with and bound by out the terms of service outlined below. These terms apply to the entire website and any email or other type of communication between you and eastcoast.asia. 

Under no circumstances shall eastcoast.asia team be liable for any direct, indirect, special, incidental, or consequential damages, including, but not limited to, loss of data or profit, arising out of the use, or the inability to use, the materials on this site or, even if eastcoast.asia team or an authorized representative has been advised of the possibility of such damage. If your use of materials from this site results in the need for servicing, repair or correction of equipment or data, you assume any costs thereof. 

eastcoast.asia will not be responsible for any outcome that may occur during the course of usage of our resources. We reserve the rights to change prices and revise the resources usage policy in any moment.
